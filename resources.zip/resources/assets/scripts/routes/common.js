export default {
  init() {
    // JavaScript to be fired on all pages

    // Gravity form hacks ///////////////////////////////////////////
    $("#gravity-fake-submit-button").on("click", function () {
      $(this).addClass("loading");
      $(".gform_wrapper form").trigger("submit");
    });

    jQuery(document).on("gform_post_render", function () {
      // code to trigger on form or form page render
      $("#gravity-fake-submit-button").removeClass("loading");
    });

    jQuery(document).on("gform_confirmation_loaded", function () {
      // code to be trigger when confirmation page is loaded
      $("#gravity-fake-submit-button").remove();
    });

    // WP Page navi hack //////////////////////////////////////////////
    if ($(".wp-pagenavi").length > 0) {
      if ($(".previouspostslink").length > 0) {
        $(".wp-pagenavi").prepend($(".previouspostslink"));
      }
    }

    // MOBILE MENU TOGGLE //
    $("#mobile-menu-toggle").on("click", function () {
      $("#mobile-menu-panel").addClass("active");
    });
    $("#close-mobile-menu-panel").on("click", function () {
      $("#mobile-menu-panel").removeClass("active");
      setTimeout(() => {
        $(".nav-mobile .menu-item-has-children").removeClass("active");
        $(".nav-mobile .menu-item-has-children .sub-menu").addClass("close");
        $(".nav-mobile .menu-item-has-children .sub-menu").slideUp(400);
      }, 300);
    });

    // Initialise collapse for mobile nav menu
    var idx = 1;
    $(".nav-mobile .menu-item-has-children").each(function () {
      var elm = $(this);
      // Setting up collapse
      elm.find(".sub-menu").attr("id", "mobile-submenu-" + idx);
      elm.find(".sub-menu").addClass("mobile-submenu collapse close");
      elm.find(".sub-menu").slideUp(400);
      // Setting up toggle
      elm.attr("data-target", "#mobile-submenu-" + idx);
      elm.attr("data-group", ".mobile-submenu");
      elm.attr("data-limit", "one");
      elm.addClass("collapse-toggle mobile-submenu");
      idx++;
    });

    // Collapse ////////////////////////////////////////////////////////
    // Initialized collapse elements
    $(".collapse").each(function () {
      var elm = $(this);
      var h = elm[0].scrollHeight;

      elm[0].style.height = h + "px";
    });

    // When collapse toggle is clicked
    $("body").on("click", ".collapse-toggle", function () {
      var toggle = $(this);
      var group = $(this).data("group");
      var target = $($(this).data("target"));
      var limit = $(this).data("limit");

      if (limit === "any") {
        if (!toggle.hasClass("active")) {
          $(group + ".collapse-toggle.active").removeClass("active");
          $(group + ".collapse")
            .not(".close")
            .addClass("close");
        }

        target.toggleClass("close");
        toggle.toggleClass("active");
      } else {
        $(group + ".collapse-toggle").removeClass("active");
        toggle.addClass("active");
        $(group + ".collapse").addClass("close");
        target.removeClass("close");
      }

      var slickTarget = $(this).data("slick");

      if (slickTarget !== undefined) {
        var slideIndex = $(this).data("goto");

        $(slickTarget).slick("slickGoTo", parseInt(slideIndex));
      }
    });

    // When window resize update collapse element height
    $(window).resize(function () {
      $(".collapse").each(function () {
        var elm = $(this);

        elm[0].style.height = "auto";

        var h = elm[0].scrollHeight;

        elm[0].style.height = h + "px";
      });
    });
    // Collapse //////////////////////////////////////////////////////// END

    // Slide-Text //
    $(".text-slide").slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: false,
      arrows: false,
      prevArrow: false,
      nextArrow: false,
    });
    // Slides END //

    // Slide-Image //
    $(".image-slide").slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      dots: true,
      arrows: false,
      autoplay: true,
    });
    // Slides END //
  },

  finalize() {
    // JavaScript to be fired on all pages, after page specific JS is fired

    // Load More news posts if available
    var news_page = 2;
    const loadmore_news_btn = $("#all-news-list .btn-loadmore");
    loadmore_news_btn.on("click", function () {
      const elm = $(this);
      const loader = elm.siblings("#loader");
      var data = {
        action: "load_news_posts_by_ajax",
        page: news_page,
        security: window.my_ajax_object.security,
      };
      elm.addClass("btn-disabled");
      loader.css("visibility", "visible");

      $.post(window.my_ajax_object.ajax_url, data, function (response) {
        if ($.trim(response) != "") {
          $("#all-news-list .news-list").append(response);
          news_page++;
        } else {
          elm.hide();
        }
        elm.removeClass("btn-disabled");
        loader.css("visibility", "hidden");
      });
    });
  },
};
