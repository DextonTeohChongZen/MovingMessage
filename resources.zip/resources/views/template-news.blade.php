{{--
  Template Name: News
--}}


@extends('layouts.app')

@section('content')
  @while(have_posts()) @php the_post() @endphp
    @include('partials.page-header')

    {{-- Nieuws --}}
    <div class="container">
      <div class="py-20 flex flex-wrap">
        <h1 class="py-10 lg:text-2xl">{{ get_the_title() }}</h1>

        <div id="all-news-list">

          <div class="news-list w-full -mx-6 flex flex-wrap">

            @php
            $current_page = 1;
            $args = array(
              'post_type'         => 'post', // Post type to query
              'order'             => 'DESC', // Newest first
              'orderby'           => 'date', // Order by published date
              'posts_per_page'    => get_posts_per_page_news(), // Query only 2 posts
              'paged'             => $current_page,
              'post_status'       => array('publish'), // Query only published posts
              );
            $wp_query = new WP_Query($args); // Call WP_Query to get posts
            if($wp_query->have_posts()): // If posts exists
          @endphp

              @php
                while ($wp_query->have_posts()) : $wp_query->the_post(); // Loop all posts
              @endphp

              @include('partials.newsfeed-grid')

              @php
                endwhile; // End of loop
              @endphp
          @php
            wp_reset_postdata(); // Very important, must include this after done with WP_Query
            wp_reset_query(); // Very important, must include this after done with WP_Query
            endif;
          @endphp
          </div>

          <div id="btn-loadmore-wrapper" class="mt-10 flex items-center justify-center">
            <a class="btn-loadmore py-4 px-10 rounded-full border-blue1 border text-blue1 text-xs">MEER LADEN</a>
            <div id="loader" class="ml-4"></div>
          </div>

        </div>
      </div>
    </div>

  @endwhile
@endsection

