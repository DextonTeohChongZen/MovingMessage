{{--
  Template Name: Contact
--}}


@extends('layouts.app')

@section('content')
  @while(have_posts()) @php the_post() @endphp
    @include('partials.page-header')
    @include('partials.content-page')

{{-- <div class="container">
  <div class="py-20 flex flex-row flex-wrap lg:flex-no-wrap">

    <div class="pt-20 w-full pr-0 lg:pr-10 lg:w-3/5">
      <h1 class="mb-10 lg:text-2xl text-black1">Contact</h1>
      <h5 class="w-full lg:w-3/4 text-grey3">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.<br>
        <br>
        Adresgegevens<br>
        <br>
        Telefoonnummer<br>
        Info@movingmessage.com<br>
      </h5>

      <div class="py-4 lg:py-10">
        <div class="w-1/3">
          <div class="py-4 flex flex-row items-center">
            <div class="w-1/2">
              <div class="sm_blacklogo ig_logo bg-center bg-no-repeat" style="background-image: url('@asset("images/ig_black.svg")')"></div>
            </div>
            <div class="logo-name">Instagram</div>
          </div>

          <div class="py-4 flex flex-row items-center">
            <div class="w-1/2">
              <div class="sm_blacklogo twitter_logo bg-center bg-no-repeat" style="background-image: url('@asset("images/twitter_black.svg")')"></div>
            </div>
            <div class="logo-name">Twitter</div>
          </div>

          <div class="py-4 flex flex-row items-center">
            <div class="w-1/2">
              <div class="sm_blacklogo linkedin_logo bg-center bg-no-repeat" style="background-image: url('@asset("images/linkedin_black.svg")')"></div>
            </div>
              <div class="logo-name">LinkedIn</div>
          </div>

          <div class="py-4 flex flex-row items-center">
            <div class="w-1/2">
              <div class="sm_blacklogo fb_logo bg-center bg-no-repeat" style="background-image: url('@asset("images/fb_black.svg")')"></div>
            </div>
            <div class="logo-name">Facebook</div>
          </div>
        </div>
      </div>
    </div>

    <div class="w-full lg:w-3/5 px-0 lg:px-4 pt-10 lg:pt-20 flex flex-col flex-wrap">
      <div class="w-full">
        <h3 class="">Stuur een bericht. Ons team staat voor je klaar!</h3>
        <br>
        <h5 class="text-grey3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>

        <div class="w-full flex flex-row">
          <div class="py-6 w-1/6">
            <div class="contact-circle rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white border-4"></div>
          </div>
          <div class="py-6 -mx-4 w-1/6">
            <div class="contact-circle rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-4"></div>
          </div>
          <div class="py-6 -mx-4 w-1/6">
            <div class="contact-circle rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-4"></div>
          </div>
          <div class="py-6 w-1/6">
            <div class="contact-circle rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-4"></div>
          </div>
        </div>
      </div>
    </div>

  </div>
</div> --}}

  @endwhile
@endsection
