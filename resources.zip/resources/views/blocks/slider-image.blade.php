<div class="container">
  <div class="py-20 flex flex-row flex-wrap items-center">

    <div class="image-area relative w-full lg:w-1/2 lg:pr-20">
      <div class="image-slide">

        @php
        // Check rows exists.
        if( have_rows('slider_content') ):

        // Loop through rows.
        while( have_rows('slider_content') ) : the_row();
        @endphp

        <div class="single-image relative border-black1 border-20 rounded-xl">
          <div class="slide-image bg-center bg-cover bg-no-repeat" style="background-image: url({{ get_sub_field('image') }})"></div>
        </div>

        @php
        // End loop.
          endwhile;

          endif;
        @endphp

      </div>
    </div>

    <div class="w-full lg:w-1/2 lg:pl-20 mt-10 lg:mt-0">
      <h6 class="text-blue1 tracking-2xwide">{{ get_sub_field('blue_title') }}</h6>
      <h2 class="my-4 lg:text-xl text-black1">{{ get_sub_field('title') }}</h2>
      <h5 class="my-10 w-full text-grey">{{ get_sub_field('content') }}</h5>
    </div>

  </div>
</div>
