<div class="block-advertenties container">
  <div class="py-20 flex flex-wrap">

    <div class="text-area my-0 lg:my-20 w-full lg:w-3/5 lg:py-20 lg:pr-10">
      <div class="text-slide">

        @php
        // Check rows exists.
        if( have_rows('slider_content') ):

        // Loop through rows.
        while( have_rows('slider_content') ) : the_row();
        @endphp

        <div class="single-text">
          <h6 class="text-blue1 tracking-3xwide">{{ get_sub_field('slider_blue_title') }}</h6>
          <h2 class="mb-8 lg:text-xl text-black1">{{ get_sub_field('slider_title') }}</h2>
          <h5 class="mb-8 text-grey lg:w-3/5">{{ get_sub_field('slider_content') }}</h5>
        </div>

        @php
        // End loop.
          endwhile;

          endif;
        @endphp

        {{-- <div class="mb-8 -mx-2 w-1/4 flex flex-row">
          <div class="px-6 py-4 mx-2 rounded-full border-2 border-grey1"><</div>
          <div class="px-6 py-4 mx-2 rounded-full border-2 border-grey1">></div>
        </div> --}}
    </div>
  </div>

  <div class="my-20 lg:my-0 w-full lg:w-2/5">
    <div class="slidetext-image bg-center bg-cover bg-no-repeat" style="background-image: url({{ get_sub_field('image') }})"></div>
  </div>

  </div>
</div>
