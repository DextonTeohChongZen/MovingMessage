<div class="bg-white1">
  <div class="block-portal container">
    <div class="pt-20 pb-10 flex flex-col flex-wrap">

      <div class="w-full lg:w-2/5 py-4">
        <h6 class="text-blue1 tracking-3xwide">{{ get_sub_field('blue_title') }}</h6>
        <h2 class="mb-8 lg:text-xl text-black1">{{ get_sub_field('title') }}</h2>
        <h5 class="mb-8 text-grey">{{ get_sub_field('content') }}</h5>
      </div>

      <div class="w-full -mx-6 flex flex-wrap">

        @php
        // Check rows exists.
        if( have_rows('portal_pages') ):

        // Loop through rows.
        while( have_rows('portal_pages') ) : the_row();
        @endphp

        <div href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
          <div class="portal-image mb-10 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url({{ get_sub_field('image') }})"></div>
          <h3 class="text-black1">{{ get_sub_field('title') }}</h3>
          <h5 class="mb-10 text-grey">{{ get_sub_field('content') }}</h5>

{{-- @php
    var_dump(get_sub_field('button'));
@endphp --}}

          @if(get_sub_field('button'))
          @component('components.button', [
          'link'   => get_sub_field('button')['url'],
          'text'    => get_sub_field('button')['title'],
          'target'   => get_sub_field('button')['target'],
          ])@endcomponent
          @endif
        </div>

        @php
        // End loop.
          endwhile;

          endif;
        @endphp

      </div>

    </div>
  </div>
</div>
