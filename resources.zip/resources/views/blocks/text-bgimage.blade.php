<div class="background-image py-10 bg-bottom bg-cover bg-no-repeat" style="background-image: url({{ get_sub_field('background_image') }})">
  <div class="container">
    <div class="py-40 w-1/2">
      <h6 class="text-white tracking-3xwide">{{ get_sub_field('blue_title') }}</h6>
      <h2 class="mb-8 lg:text-xl text-white">{{ get_sub_field('title') }}</h2>
      <h5 class="mb-8 text-white text-opacity-50">{{ get_sub_field('content') }}</h5>
    </div>
  </div>
</div>
