<div class="block-news container">
  <div class="py-20 flex flex-wrap">
    <div class="w-full py-8">
      <h2 class="lg:text-xl text-black1">{{ get_sub_field('title') }}</h2>
    </div>

    <div class="w-full md:-mx-6 flex flex-wrap">

    @php
    // Check rows exists.
    if( have_rows('main_news') ):

    // Loop through rows.
    while( have_rows('main_news') ) : the_row();
    @endphp

      <a href="" class="w-full py-4 lg:py-0 px-0 md:px-6 md:w-1/2 xl:w-1/3 inline-block">
        <div class="news-image mb-2 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url({{ get_sub_field('image') }})"></div>
        <h6 class="text-grey1 text-right">{{ get_sub_field('date') }}</h6>
        <h4 class="mt-4 text-black1">{{ get_sub_field('content_title') }}</h4>
      </a>

    @php
    // End loop.
      endwhile;

      endif;
    @endphp


      <div class="w-full mt-10 px-6 xl:w-1/3 xl:mt-0 inline-block">

        @php
        // Check rows exists.
        if( have_rows('sub_news') ):

        // Loop through rows.
        while( have_rows('sub_news') ) : the_row();
        @endphp

        <a href="" class="mb-8 flex flex-row items-center">
          <div class="w-2/5">
            <div class="sidenews-image bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url({{ get_sub_field('image') }})"></div>
          </div>
          <h5 class="w-3/5 ml-6 mb-0 text-black1">{{ get_sub_field('content_title') }}</h5>
        </a>

        @php
        // End loop.
          endwhile;

          endif;
        @endphp

        <a href="" class="mb-8 flex flex-row items-center">
          <div class="w-full lg:w-2/3 mt-4 flex justify-center lg:justify-end">

            @if(get_sub_field('button'))
            @component('components.button', [
          'link'   => get_sub_field('button')['url'],
          'text'    => get_sub_field('button')['title'],
          'target'   => get_sub_field('button')['target'],
            ])@endcomponent
            @endif

          </div>
        </a>

      </div>

    </div>

  </div>
</div>
