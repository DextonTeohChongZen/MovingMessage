    <div class="py-20 w-full flex flex-row flex-wrap justify-center items-center">
      <div class="w-1/12 mx-4">
        <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1" style="background-image: url({{ get_sub_field('image') }})"></div>
      </div>
      <h3 class="text-black1">{{ get_sub_field('title') }}<br><a class="text-blue1" href="{{ get_sub_field('link') }}">{{ get_sub_field('link_name') }}</a></h3>
    </div>
