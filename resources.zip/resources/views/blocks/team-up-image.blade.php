<div class="container">
  <div class="py-20 flex flex-wrap items-center">

    <div class="lg:pr-20 w-full lg:w-1/2">
      <div class="truck-image bg-center bg-cover bg-no-repeat" style="background-image: url({{ get_sub_field('image') }})"></div>
    </div>

    <div class="py-10 lg:pl-10 w-full lg:w-1/2">
      <div class="py-8">
        <h6 class="text-blue1 tracking-3xwide">{{ get_sub_field('blue_title') }}</h6>
        <h2 class="mb-8 lg:text-xl text-black1">{{ get_sub_field('title') }}</h2>
        <h5 class="mb-8 text-grey">{{ get_sub_field('content') }}</h5>
      </div>

      <div class="-mx-8 flex flex-row flex-wrap">

        @php
        // Check rows exists.
        if( have_rows('group') ):

        // Loop through rows.
        while( have_rows('group') ) : the_row();
        @endphp

        <div class="mb-8 px-8 w-full lg:w-1/2">
          <div class="mb-6 w-1/3">
            <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1" style="background-image: url({{ get_sub_field('group_image') }}"></div>
          </div>
          <h3 class="text-black1">{{ get_sub_field('group_title') }}</h3>
          <h5 class="w-full text-grey">{{ get_sub_field('group_content') }}</h5>
        </div>

        @php
        // End loop.
          endwhile;

          endif;
        @endphp

      </div>
    </div>

  </div>
</div>
