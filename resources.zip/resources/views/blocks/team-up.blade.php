<div class="block-teamup container">
  <div class="py-20 flex flex-wrap">

    <div class="py-4 w-full lg:w-1/2 xl:w-2/5">
      <h6 class="text-blue1 tracking-3xwide">{{ get_sub_field('blue_title') }}</h6>
      <h2 class="mb-8 lg:text-xl text-black1">{{ get_sub_field('title') }}</h2>
      <h5 class="mb-8 text-grey">{{ get_sub_field('content') }}</h5>
    </div>

    <div class="py-20 -mx-10 flex flex-row flex-wrap">

      @php
      // Check rows exists.
      if( have_rows('group') ):

      // Loop through rows.
      while( have_rows('group') ) : the_row();
      @endphp

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="rounded-full bg-grey1 border-white1 border-1">
            <div class="teamup-image bg-center bg-cover bg-no-repeat" style="background-image: url({{ get_sub_field('group_image') }}"></div>
          </div>
        </div>
        <h3 class="text-black1">{{ get_sub_field('group_title') }}</h3>
        <h5 class="w-full text-grey">{{ get_sub_field('group_content') }}</h5>
      </div>

      @php
      // End loop.
        endwhile;

        endif;
      @endphp

    </div>

  </div>
</div>
