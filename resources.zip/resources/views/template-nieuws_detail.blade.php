{{--
  Template Name: Nieuws Detail
--}}


@extends('layouts.app')

@section('content')
  @while(have_posts()) @php the_post() @endphp
    @include('partials.page-header')
    @include('partials.content-page')

    {{-- <div class="container">
  <div class="py-20 flex flex-wrap">
    <a href="" class="flex flex-row">
      <div class="mb-10 lg:mb-0">
        <button class="text-blue1 border-blue1 border">TERUG</button>
      </div>
    </a>

    <div class="lg:w-3/5 px-0 lg:px-20">
      <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url('@asset("images/img.png")')"></div>
      <h6 class="mb-6 text-grey1">22-02-2021</h6>
      <h3 class="mb-10 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis.</h3>
      <h5 class="w-full text-grey">
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed fringilla luctus lectus eget posuere. Nulla facilisi. Aliquam vestibulum erat sit amet diam pulvinar dapibus. Integer lobortis lobortis libero quis accumsan. Sed pellentesque lacus odio, nec auctor risus placerat in. Sed efficitur scelerisque convallis. Quisque justo sapien, molestie nec dapibus et, ullamcorper nec sem. Etiam eget suscipit augue. Vestibulum et tristique lorem. Aliquam pulvinar est sed risus congue laoreet a sit amet diam. Suspendisse potenti. Nullam pretium tellus libero, et sagittis erat egestas at. Donec sem sapien, ultrices vitae efficitur eu, hendrerit nec sem. Pellentesque fermentum, purus id varius interdum, ipsum justo tempor lorem, sit amet cursus nisl dolor lobortis enim.<br>
      <br>
      Quisque ac leo ut augue convallis gravida vitae vitae magna. Sed posuere egestas pulvinar. Sed tempor enim a ipsum consequat mattis. Nunc interdum tellus vel malesuada pretium. In at elit aliquet, commodo metus in, convallis mauris. Etiam hendrerit feugiat felis sit amet tempor. Duis placerat dolor sagittis mi consectetur bibendum.<br>
      <br>
      Vestibulum pellentesque eros ut elementum convallis. Mauris eget diam et massa scelerisque tempus. Proin ultrices ante at neque volutpat feugiat. Mauris tempor nisi in augue aliquam, consectetur tincidunt lacus tempor. Cras tincidunt leo a diam dapibus rutrum. In faucibus porttitor libero pellentesque tincidunt. Aliquam bibendum condimentum diam, eget lobortis ex. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum in faucibus enim, vel ornare metus.<br>
      <br>
      Nulla odio tellus, elementum sit amet dictum posuere, elementum a arcu. Aenean ac placerat quam. Donec id nulla eget nunc laoreet tristique. Proin rutrum felis eget nisl eleifend convallis. Donec ac tortor ullamcorper, egestas orci id, porttitor dolor. Sed lobortis fermentum sapien, in dictum diam varius eget. Fusce sit amet eros vel est rhoncus vestibulum. Quisque lobortis massa quis volutpat sodales. Cras aliquet ex at massa bibendum bibendum. Proin scelerisque commodo magna, ultricies finibus lectus elementum in. Phasellus lobortis accumsan elementum. Integer at orci non quam faucibus vehicula. Interdum et malesuada fames ac ante ipsum primis in faucibus.<br>
      </h5>
    </div>

    <div class="lg:w-1/5 mt-20 lg:mt-0 ml-0 lg:ml-10 flex flex-col flex-wrap">
      <a href="" class="w-full mb-10 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full mb-10 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>
    </div>

  </div>
</div> --}}

  @endwhile
@endsection
