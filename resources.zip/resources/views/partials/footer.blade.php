<div class="bg-white2">
  <div class="container">
    <div class="py-20 flex flex-row flex-wrap">

      <div class="w-full lg:w-1/2">
        <h2 class="">{{ get_field('title', 'options') }}</h2>
        <h4 class="text-grey2">{{ get_field('content', 'options') }}</h4>
        <br>
        <a href="mailto:{{ get_field('email', 'options') }}" class="my-10 text-md lg:text-lg text-blue1 underline">{{ get_field('email', 'options') }}</a>
        <div class="pt-20 -mx-5 flex flex-row">

          @php
          // Check rows exists.
          if( have_rows('link', 'options') ):

          // Loop through rows.
          while( have_rows('link', 'options') ) : the_row();
          @endphp

          <a class="footerlink px-5 text-white3 text-xs lg:text-base" href="{{ get_sub_field('footer_link', 'options') }}">{{ get_sub_field('footer_name', 'options') }}<a>

          @php
          // End loop.
            endwhile;

            endif;
          @endphp

        </div>
      </div>

      <div class="w-full lg:w-1/2 pl-0 lg:pl-10">
        <div class="w-full lg:w-1/2 flex flex-col pt-10 lg:pt-0 lg:float-right">

          @php
          // Check rows exists.
          if( have_rows('sm', 'options') ):

          // Loop through rows.
          while( have_rows('sm', 'options') ) : the_row();
          @endphp

{{-- @php
    var_dump(get_sub_field('sm_link', 'options'));
@endphp --}}

          <a class="social py-2 flex lg:flex-row items-center" href="{{ get_sub_field('sm_link', 'options') }}">
            <div class="p-3 lg:p-6 sm_whitelogo ig_logo rounded-full bg-black bg-center bg-no-repeat" style="background-image: url({{ get_sub_field('sm_logo', 'options') }})"></div>
            <div class="logo-name pl-5 lg:pl-10">{{ get_sub_field('sm_name', 'options') }}</div>
          </a>

          @php
          // End loop.
            endwhile;

            endif;
          @endphp
        </div>
      </div>

    </div>
  </div>
</div>

