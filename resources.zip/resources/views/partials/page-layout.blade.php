@if( have_rows('flexible_layout') )
  @while ( have_rows('flexible_layout') ) @php the_row(); @endphp

    @if( get_row_layout() == 'intro' )
        @include('blocks.intro')

    @elseif( get_row_layout() == 'portal' )
      @include('blocks.portal')

    @elseif( get_row_layout() == 'nieuws-block' )
      @include('blocks.nieuws-block')

    @elseif( get_row_layout() == 'team-up' )
      @include('blocks.team-up')

    @elseif( get_row_layout() == 'text-image' )
      @include('blocks.text-image')

    @elseif( get_row_layout() == 'text-bgimage' )
      @include('blocks.text-bgimage')

    @elseif( get_row_layout() == 'slider-text' )
      @include('blocks.slider-text')

    @elseif( get_row_layout() == 'slider-image' )
      @include('blocks.slider-image')

      @elseif( get_row_layout() == 'price' )
      @include('blocks.price')

    @elseif( get_row_layout() == 'team-up-image' )
      @include('blocks.team-up-image')

    @elseif( get_row_layout() == 'contact' )
      @include('blocks.contact')

    @elseif( get_row_layout() == 'question' )
      @include('blocks.question')

    @endif
  @endwhile
@endif
