@php
  $image = get_the_post_thumbnail_url();
  $date = get_the_date('d-m-Y');
  $url = get_the_permalink(); // get the URL of the post
@endphp

<a href="{{ $url }}" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
  <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url({{ get_the_post_thumbnail_url() }})"></div>
  <h6 class="mb-6 text-grey1 text-right">{{ $date }}</h6>
  <h4 class="mb-8 font-normal">{{ get_the_title() }}</h4>
</a>
