{{--
  Template Name: Adverteerders
--}}


@extends('layouts.app')

@section('content')
  @while(have_posts()) @php the_post() @endphp
    @include('partials.page-header')

{{-- MAIN --}}
  <div class="block-adverteerders-main container">
    <div class="py-20 flex flex-row flex-wrap justify-start">

      <div class="my-4 w-full lg:w-1/2">
        <h1 class="my-6 lg:text-2xl text-black1">Adverteerders</h1>
        <h4 class="my-6 lg:w-4/5 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis.</h4>
        <h5 class="w-full lg:w-4/5 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
        <button class="my-10 bg-blue1 text-white">LEES MEER</button>
      </div>

      <div class="my-4 w-full lg:w-1/2 lg:my-0">
        <div class="home-image bg-center bg-cover bg-no-repeat border-white1 border-2 border-opacity-75" style="background-image: url('@asset("images/img.png")')"></div>
      </div>

    </div>
  </div>

{{-- PORTAL --}}
  <div class="bg-white1">
    <div class="block-portal container">
      <div class="pt-20 pb-10 flex flex-col flex-wrap">

        <div class="w-full lg:w-2/5 py-4">
          <h6 class="text-blue1 tracking-3xwide">PORTAL</h6>
          <h2 class="mb-8 lg:text-xl text-black1">Voor wie</h2>
          <h5 class="mb-8 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
        </div>

        <div class="w-full -mx-6 flex flex-wrap">
          <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
            <div class="portal-image mb-10 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url('@asset("images/img5.png")')"></div>
            <h3 class="text-black1">Adverteerders</h3>
            <h5 class="mb-10 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
          </a>

          <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
            <div class="portal-image mb-10 bg-center bg-cover bg-no-repeat border-white1 border-1" style="background-image: url('@asset("images/img6.png")')"></div>
            <h3 class="text-black1">Transporteurs</h3>
            <h5 class="mb-10 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
          </a>

          <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
            <div class="portal-image mb-10 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url('@asset("images/img1.png")')"></div>
            <h3 class="text-black1 text-lg leading-tight">Organisaties</h3>
            <h5 class="mb-10 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
          </a>
        </div>

      </div>
    </div>
  </div>

{{-- TEAM UP --}}
<div class="block-teamup container">
  <div class="py-20 flex flex-wrap">
    <div class="py-4 w-full lg:w-1/2 xl:w-2/5">
      <h6 class="text-blue1 tracking-3xwide">TEAM UP</h6>
      <h2 class="mb-8 lg:text-xl text-black1">De voordelen van een MovingMessage scherm</h2>
      <h5 class="mb-8 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
    </div>

    <div class="py-20 -mx-10 flex flex-row flex-wrap">
      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
        </div>
        <h3 class="text-black1">Geo-locatie</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
        </div>
        <h3 class="text-black1">e-Paper</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
        </div>
        <h3 class="text-black1">Content</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
        </div>
        <h3 class="text-black1">e-Paper</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>
    </div>
  </div>
</div>

{{-- SLIDE-TEXT --}}
<div class="block-advertenties container">
  <div class="py-20 flex flex-wrap">

    <div class="text-area my-0 lg:my-20 w-full lg:w-3/5 lg:py-20 lg:pr-10">
      <div class="text-slide">
        <div class="single-text">
          <h6 class="text-blue1 tracking-3xwide">MOGELIJKHEDEN</h6>
          <h2 class="mb-8 lg:text-xl text-black1">Advertenties</h2>
          <h5 class="mb-8 text-grey lg:w-3/5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
        </div>

        <div class="single-text">
          <h6 class="text-blue1 tracking-3xwide">MOGELIJKHEDEN</h6>
          <h2 class="mb-8 lg:text-xl text-black1">Advertenties</h2>
          <h5 class="mb-8 text-grey lg:w-3/5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
        </div>
      </div>

        {{-- <div class="mb-8 -mx-2 w-1/4 flex flex-row">
          <div class="px-6 py-4 mx-2 rounded-full border-2 border-grey1"><</div>
          <div class="px-6 py-4 mx-2 rounded-full border-2 border-grey1">></div>
        </div> --}}
    </div>

    <div class="my-20 lg:my-0 w-full lg:w-2/5">
      <div class="slidetext-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/truck.png")')"></div>
    </div>
  </div>
</div>

{{-- SLIDE-IMAGE --}}
<div class="container">
  <div class="py-20 flex flex-row flex-wrap items-center">

    <div class="image-area relative w-full lg:w-1/2 lg:pr-20">
      <div class="image-slide">
        <div class="single-image relative border-black1 border-20 rounded-xl">
          <div class="slide-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/library.png")"></div>
        </div>

        <div class="single-image relative border-black1 border-20 rounded-xl">
          <div class="slide-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/img3.png")"></div>
        </div>

        <div class="single-image relative border-black1 border-20 rounded-xl">
          <div class="slide-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/img4.png")"></div>
        </div>

        <div class="single-image relative border-black1 border-20 rounded-xl">
          <div class="slide-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/img1.png")"></div>
        </div>
      </div>
    </div>

    <div class="w-full lg:w-1/2 lg:pl-20 mt-10 lg:mt-0">
      <h6 class="text-blue1 tracking-2xwide">MOGELIJKHEDEN</h6>
      <h2 class="my-4 lg:text-xl text-black1">Asset & campagne management</h2>
      <h5 class="my-10 w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
    </div>

  </div>
</div>

{{-- STUDIO --}}
<div class="studio-image py-10 bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/studio.png")')">
  <div class="container">
    <div class="py-40 w-1/2">
      <h6 class="text-white tracking-3xwide">STUDIO</h6>
      <h2 class="mb-8 lg:text-xl text-white">Creative support</h2>
      <h5 class="mb-8 text-white text-opacity-50">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
    </div>
  </div>
</div>

{{-- HOVERBOX --}}
<div class="container">
  <div class="py-20 flex flex-wrap">
    <div class="w-full">
      <h6 class="text-blue1 tracking-2xwide">prijzen</h6>
      <h2 class="my-6 lg:text-xl text-black1">Oplossingen voor elke scope</h2>
      <h5 class="w-full lg:w-1/2 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
    </div>

    <div class="w-full py-10 flex flex-row flex-wrap text-center">
      <div class="hoverbox p-20 w-full lg:w-1/3">
        <h3 class="my-6 text-black1">Small</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        <h2 class="w-full lg:text-xl">€ 50,- </h2>
        <h5 class="w-full text-grey">Per maand</h5>
      </div>

      <div class="hoverbox p-20 w-full lg:w-1/3">
        <h3 class="my-6 text-black1">Medium</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        <h2 class="w-full lg:text-xl">€ 75,- </h2>
        <h5 class="w-full text-grey">Per maand</h5>
      </div>

      <div class="hoverbox p-20 w-full lg:w-1/3">
        <h3 class="my-6 text-black1">Large</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        <h2 class="w-full lg:text-xl">€ 100,- </h2>
        <h5 class="w-full text-grey">Per maand</h5>
      </div>
    </div>

    <div class="w-full flex flex-row flex-wrap justify-center items-center">
      <div class="w-1/12 mx-4">
        <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
      </div>
      <h3 class="text-black1">Vragen? Neem contact op met Gijs<br><a class="text-blue1">gijs@movingmessage.com</a></h3>
    </div>
  </div>
</div>

  @endwhile
@endsection
