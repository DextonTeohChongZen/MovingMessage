<a
  class="button bg-{{$type ?: 'blue1'}} {{$class}}"
  {{$link ? 'href='.$link.'': false }}
  target={{$target ?: '_self'}}
>{!! $text !!}</a>
