{{--
  Template Name: Custom Template
--}}


@extends('layouts.app')

@section('content')
  @while(have_posts()) @php the_post() @endphp
    @include('partials.page-header')
    @include('partials.content-page')

    <div class="py-20">
      <div class="container py-10">
        <div class="py-10 bg-teal">
          <div class="flex flex-wrap justify-between -mx-4">
            <div class="w-full sm:w-6/12 lg:w-1/12 px-4">
              <div class="bg-black">COL</div>
            </div>
            <div class="w-full sm:w-6/12 lg:w-3/12 px-4">
              <div class="bg-primary">COL</div>
            </div>
            <div class="w-full lg:w-8/12 px-4">
              <div class="bg-purple">COL</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    @include('blocks.contact')
  @endwhile
@endsection

