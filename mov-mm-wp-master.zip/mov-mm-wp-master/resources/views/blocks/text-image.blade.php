<div class="{{ get_sub_field('background_color') }}">
  <div class="container">
    <div class="py-20 -mx-10 flex flex-wrap items-center {{ get_sub_field('image_position') === 'right' ? 'flex-row-reverse' : 'flex-row'}}">

      <div class="w-full pb-10 lg:w-1/2 px-10 lg:pb-0">
        <div class="text-image bg-center bg-cover bg-no-repeat border-white1 border-1 {{ get_sub_field('background_color') === 'bg-white' ? 'bg-white2' : 'bg-white'}}" style="background-image: url({{ get_sub_field('image') }})"></div>
      </div>

      <div class="w-full px-10 lg:w-1/2 mt-10 lg:mt-0">
        <h6 class="text-blue1 tracking-3xwide">{{ get_sub_field('blue_title') }}</h6>
        <h2 class="mb-8 text-black1">{{ get_sub_field('title') }}</h2>
        <h5 class="mb-8 text-grey">{{ get_sub_field('content') }}</h5>
      </div>

    </div>
  </div>
</div>
