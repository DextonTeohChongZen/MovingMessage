<div class="block-home container">
  <div class="py-10 lg:py-20 flex flex-wrap justify-start {{ get_sub_field('image_position') === 'left' ? 'flex-col-reverse lg:flex-row-reverse' : 'flex-col-reverse lg:flex-row'}}">

    <div class="my-4 w-full lg:w-1/2 {{ get_sub_field('image_position') === 'left' ? 'pl-0 lg:pl-10' : 'pr-0 lg:pr-10'}}">
      <h6 class="text-blue1 tracking-2xwide">{{ get_sub_field('blue_title') }}</h6>
      <h1 class="my-6 lg:text-2xl text-black1">{{ get_sub_field('title') }}</h1>
      <h5 class="w-full text-grey">{!!get_sub_field('content')!!}</h5>

      @if(get_sub_field('button'))
      @component('components.button', [
          'link'   => get_sub_field('button')['url'],
          'text'    => get_sub_field('button')['title'],
          'target'   => get_sub_field('button')['target'],
          'class'   => 'my-10',
      ])@endcomponent
      @endif

    </div>

    <div class="w-full lg:w-1/2 my-4 lg:my-0 {{ get_sub_field('image_position') === 'left' ? 'pr-0 lg:pr-10' : 'pl-0 lg:pl-10'}}">
      <div class="home-image bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-2 border-opacity-75" style="background-image: url({{ get_sub_field('image') }})"></div>
    </div>

  </div>
</div>
