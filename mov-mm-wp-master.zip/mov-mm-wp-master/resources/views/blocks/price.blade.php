<div class="container">
  <div class="py-20 flex flex-wrap">
    <div class="w-full">
      <h6 class="text-blue1 tracking-2xwide">{{ get_sub_field('blue_title') }}</h6>
      <h2 class="my-6 lg:text-xl text-black1">{{ get_sub_field('title') }}</h2>
      <h5 class="w-full lg:w-1/2 text-grey">{{ get_sub_field('content') }}</h5>
    </div>

    <div class="w-full py-10 flex flex-row flex-wrap text-center">

      @php
      // Check rows exists.
      if( have_rows('price_box') ):

      // Loop through rows.
      while( have_rows('price_box') ) : the_row();
      @endphp

      <div class="p-20 w-full lg:w-1/3 {{ get_sub_field('price_box_border') === 'yes' ? 'border-t-4 border-blue1 shadow-lg' : ''}}">
        <h3 class="my-6 text-black1">{{ get_sub_field('price_box_title') }}</h3>
        <h5 class="w-full text-grey">{{ get_sub_field('price_box_content') }}</h5>
        <h2 class="w-full lg:text-xl">{{ get_sub_field('price_box_price') }}</h2>
        <h5 class="w-full text-grey">{{ get_sub_field('price_box_tag') }}</h5>
      </div>

      @php
      // End loop.
        endwhile;

        endif;
      @endphp
    </div>

  </div>
</div>

      {{-- <div class="hoverbox p-20 w-full lg:w-1/3">
        <h3 class="my-6 text-black1">Medium</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        <h2 class="w-full lg:text-xl">€ 75,- </h2>
        <h5 class="w-full text-grey">Per maand</h5>
      </div>

      <div class="hoverbox p-20 w-full lg:w-1/3">
        <h3 class="my-6 text-black1">Large</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        <h2 class="w-full lg:text-xl">€ 100,- </h2>
        <h5 class="w-full text-grey">Per maand</h5>
      </div> --}}




