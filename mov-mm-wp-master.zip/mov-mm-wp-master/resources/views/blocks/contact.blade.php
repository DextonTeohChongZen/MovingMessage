<div class="container">
  <div class="py-20 flex flex-row flex-wrap lg:flex-no-wrap">

    <div class="pt-20 w-full pr-0 lg:pr-10 lg:w-3/5">
      <h1 class="mb-10 lg:text-2xl text-black1">{{ get_sub_field('title') }}</h1>
      <h5 class="w-full lg:w-3/4 text-grey3">
        {!! get_sub_field('title_content') !!}
      </h5>

      <div class="py-4 lg:py-10">
        <div class="w-1/3">

          @php
          // Check rows exists.
          if( have_rows('sm_logo') ):

          // Loop through rows.
          while( have_rows('sm_logo') ) : the_row();
          @endphp

          <a class="social py-4 flex flex-row items-center cursor-pointer">
            <div class="w-1/2">
              <div class="sm_blacklogo ig_logo bg-center bg-no-repeat" style="background-image: url({{ get_sub_field('sm_logo_image') }})"></div>
            </div>
            <div class="logo-name">{{ get_sub_field('sm_logo_name') }}</div>
          </a>

          @php
          // End loop.
            endwhile;

            endif;
          @endphp

        </div>
      </div>

    </div>

    <div class="w-full lg:w-3/5 px-0 lg:px-4 pt-10 lg:pt-20 flex flex-col flex-wrap">
      <div class="w-full">
        <h3 class="mb-8">{{ get_sub_field('sub_title') }}</h3>
        <h5 class="text-grey3">{!! get_sub_field('sub_title_content') !!}</h5>

        <div class="w-full flex flex-row">

          @php
          // Check rows exists.
          if( have_rows('logo') ):

          // Loop through rows.
          while( have_rows('logo') ) : the_row();
          @endphp

          <div class="py-6 -mx-4 w-1/6">
            <div class="contact-circle rounded-full bg-white2 bg-center bg-cover bg-no-repeat border-white border-4" style="background-image: url({{ get_sub_field('logo_image') }})"></div>
          </div>

          @php
          // End loop.
            endwhile;

            endif;
          @endphp

        </div>

      </div>

      <div id="form">
        {{ gravity_form( get_sub_field('form_id', 'options'), false, false, false, '', true, 20) }}
      </div>


    </div>

  </div>
</div>
