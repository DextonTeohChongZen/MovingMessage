{{--
  Template Name: Transporteurs
--}}


@extends('layouts.app')

@section('content')
  @while(have_posts()) @php the_post() @endphp
    @include('partials.page-header')

{{-- MAIN --}}
<div class="block-adverteerders-main container">
  <div class="py-20 flex flex-row flex-wrap justify-start">

    <div class="my-4 w-full lg:w-1/2">
      <h1 class="my-6 lg:text-2xl text-black1">Transporteurs</h1>
      <h4 class="my-6 lg:w-4/5 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis.</h4>
      <h5 class="w-full lg:w-4/5 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
      <button class="my-10 bg-blue1 text-white">LEES MEER</button>
    </div>

    <div class="my-4 w-full lg:w-1/2 lg:my-0">
      <div class="home-image bg-center bg-cover bg-no-repeat border-white1 border-2 border-opacity-75" style="background-image: url('@asset("images/img1.png")')"></div>
    </div>

  </div>
</div>

{{-- TEAM-UP BLOCK --}}
<div class="block-teamup container">
  <div class="py-20 flex flex-wrap">
    <div class="py-4 w-full lg:w-1/2 xl:w-2/5">
      <h6 class="text-blue1 tracking-3xwide">TEAM UP</h6>
      <h2 class="mb-8 lg:text-xl text-black1">De voordelen van een MovingMessage scherm</h2>
      <h5 class="mb-8 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
    </div>

    <div class="py-20 -mx-10 flex flex-row flex-wrap">
      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1"></div>
        </div>
        <h3 class="text-black1">Geo-locatie</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1"></div>
        </div>
        <h3 class="text-black1">e-Paper</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1"></div>
        </div>
        <h3 class="text-black1">Content</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1"></div>
        </div>
        <h3 class="text-black1">e-Paper</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>
    </div>
  </div>
</div>

{{-- TEXT + IMAGE --}}
<div class="bg-white2">
  <div class="container">
    <div class="py-20 -mx-8 flex flex-row flex-wrap items-center">

      <div class="w-full lg:w-1/2 px-8">
        <div class="text-image bg-center bg-cover bg-no-repeat bg-white1 border-white1 border-1"></div>
      </div>

      <div class="w-full lg:w-1/2 mt-10 lg:mt-0 px-8">
        <h6 class="text-blue1 tracking-3xwide">PORTAL</h6>
        <h2 class="mb-8 lg:text-xl text-black1">Verdienmodel</h2>
        <h5 class="mb-8 w-4/5 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
      </div>

    </div>
  </div>
</div>

{{-- TEXT + IMAGE 2--}}
  <div class="container">
    <div class="py-20 -mx-8 flex flex-row flex-wrap items-center">

      <div class="w-full lg:w-1/2 mt-10 lg:mt-0 px-8">
        <h6 class="text-blue1 tracking-3xwide">PORTAL</h6>
        <h2 class="mb-8 lg:text-xl text-black1">Service en onderhoud</h2>
        <h5 class="mb-8 w-5/6 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
      </div>

      <div class="w-full lg:w-1/2 px-8">
        <div class="text-image bg-center bg-cover bg-no-repeat bg-white1 border-white1 border-1"></div>
      </div>

    </div>
  </div>

  <div class="w-full flex flex-row flex-wrap justify-center items-center">
    <div class="w-1/12 mx-8">
      <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
    </div>
    <h3 class="text-black1">Vragen? Neem contact op met Gijs<br><a class="text-blue1">gijs@movingmessage.com</a></h3>
  </div>



  @endwhile
@endsection
