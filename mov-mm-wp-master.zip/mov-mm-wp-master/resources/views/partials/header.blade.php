<header class="">
  <div class="container">

    <div class="hidden lg:block">
      <div class="primary-nav py-6 flex items-center justify-between border-b border-white2">
        <a href="{{ home_url('/') }}"><img src="@asset("images/mm_logo.png")" alt="mm_logo" class="mm_logo w-1/2 lg:w-full px-4"></a>

        <div class="primary-menu flex flex-row items-center">
          <nav class="nav-primary">
            @if (has_nav_menu('primary_navigation'))
              {!! wp_nav_menu(['theme_location' => 'primary_navigation']) !!}
            @endif
          </nav>
          {{-- <a class="news text-xs">NIEUWS</a>
          <a class="ads text-xs">ADVERTEERDERS</a>
          <a class="org text-xs">TRANSPORTEURS</a>
          <a class="oo text-xs">ORGANISATIES</a>
          <a class="oo text-xs">OVER ONS</a> --}}

          <a href="{{ get_field('contact', 'options')['url'] }}" class="contact-button mx-2 xl:mx-4 py-4 px-8 bg-blue1 rounded-full text-white text-xs">{{ get_field('contact', 'options')['title'] }}</a>
          <a href="{{ get_field('login', 'options')['url'] }}" class="login-button mx-2 xl:mx-4 py-4 px-8 border-2 border-blue1 rounded-full text-blue1 text-xs">{{ get_field('login', 'options')['title'] }}</a>
        </div>
      </div>
    </div>

    <div class="lg:hidden" id="mobile-menu">
      <div class="py-4 flex flex-wrap items-center justify-between border-b border-white2">
        <a  class="w-1/12" href="{{ home_url('/') }}"><img src="@asset("images/mm_logo.svg")" alt="mm_logo" class="mm_logo"></a>
        <h6 id="mobile-menu-toggle" class="menu-toggle flex justify-end font-medium cursor-pointer">MENU</h6>
      </div>
    </div>

    <div class="mobile-menu_panel fixed left-0 bottom-0 right-0 justify-end bg-white" id="mobile-menu-panel">

        <div class="mobile-panel mx-8 py-4 flex flex-wrap items-center justify-between border-b border-white2">
          <a class="home-logo flex-grow-0 flex-shrink-0" href="{{ home_url('/') }}">
            <img src="@asset("images/mm_logo.png")" alt="mm_logo" class="mm_mobile">
          </a>
          <h6 id="close-mobile-menu-panel" class="sluiten-toggle flex justify-end cursor-pointer">SLUITEN</h6>
        </div>

        <div class="mobile-menu_body flex justify-center text-center">
          <nav class="nav-mobile">
            @if (has_nav_menu('mobile_navigation'))
              {!! wp_nav_menu(['theme_location' => 'mobile_navigation']) !!}
            @endif
          <div class="py-6 mx-8 flex flex-col">
            <a href="{{ get_field('contact', 'options')['url'] }}" class="contact-button my-2 py-4 px-10 bg-blue1 rounded-full text-white text-xs">{{ get_field('contact', 'options')['title'] }}</a>
            <a href="{{ get_field('login', 'options')['url'] }}" class="login-button my-2 py-4 px-10 border-2 border-blue1 rounded-full text-blue1 text-xs">{{ get_field('login', 'options')['title'] }}</a>
          </div>
        </nav>
        </div>

    </div>

  </div>
</header>
