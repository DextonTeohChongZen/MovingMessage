<div class="container py-10 lg:py-20">
  <div class="flex flex-row flex-wrap">

    <div class="back-button py-8 lg:py-0">
      <div class="button bg-white text-blue1 border-blue1 border">
        <a href="javascript:window.history.back()" class="reset opacity-hover back-to-overview">TERUG</a>
      </div>
    </div>

  <div class="lg:w-3/5 px-0 lg:px-20">
    <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url({{ get_the_post_thumbnail_url() }})"></div>
    <h6 class="mb-6 text-grey1">@php $post_date = get_the_date( 'j F Y' ); echo $post_date; @endphp</h6>
    <h3 class="mb-10 font-normal">{!! get_the_title() !!}</h3>
    <h5 class="w-full text-grey">{!! get_the_content() !!}</h5>
  </div>

  <div class="w-full lg:w-1/5 mt-20 lg:mt-0 flex flex-col flex-wrap">
  {{-- LATEST NEWS --}}
  @php
  $args = array(
    'post__not_in'      => [ get_the_ID() ], // Exclude current post from the query
    'post_type'         => 'post', // Post type to query
    'post_status'       => array('publish'), // Query only published posts
    'posts_per_page'    => 2, // Query only 2 posts
    'orderby'           => 'date', // Order by published date
    'order'             => 'DESC', // Newest first
    );
  $wp_query = new WP_Query($args); // Call WP_Query to get posts
  if($wp_query->have_posts()): // If posts exists
@endphp
    @php
      while ($wp_query->have_posts()) : $wp_query->the_post(); // Loop all posts
        $image = get_the_post_thumbnail_url();
        $date = get_the_date('d-m-Y');
        $url = get_the_permalink(); // get the URL of the post
    @endphp
        <a href="{{get_the_permalink()}}" class="w-full mb-10 inline-block">
          <div alt="" class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url({{ get_the_post_thumbnail_url() }})"></div>
          <div class="mb-6 text-grey1 text-right">{{$date}}</div>
          <div class="mb-8">{{ get_the_title() }}</div>
        </a>
    @php
      endwhile; // End of loop
    @endphp
@php
  wp_reset_postdata(); // Very important, must include this after done with WP_Query
  wp_reset_query(); // Very important, must include this after done with WP_Query
  endif;
@endphp

  </div>

  </div>
</div>
