{{--
  Template Name: Home
--}}

@extends('layouts.app')

@section('content')
  @while(have_posts()) @php the_post() @endphp
    @include('partials.page-header')

{{-- FIRST BLOCK --}}
  <div class="block-home container">
    <div class="py-20 flex flex-row flex-wrap justify-start">

      <div class="my-4 w-full lg:w-1/2">
        <h6 class="text-blue1 tracking-2xwide">WELKOM BIJ MOVINGMESSAGE</h6>
        <h1 class="my-6 lg:text-2xl text-black1">Een uitgebreid netwerk aan mobiele e-Ink displays</h1>
        <h5 class="w-full lg:w-3/4 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
        @if(get_sub_field('image_shape'))
        <a class="my-10 button bg-blue1 text-white">{{get_sub_field('image_shape')}}</a>
        @component('components.button', [
            'text'    => 'LEES MEER',
            'class'   => 'my-10',
        ])@endcomponent
        @endif

      </div>

      <div class="my-4 w-full lg:w-1/2 lg:pl-4 lg:my-0">
        <div class="home-image bg-center bg-cover bg-no-repeat border-white1 border-2 border-opacity-75" style="background-image: url('@asset("images/img.png")')"></div>
      </div>

    </div>
  </div>

{{-- SECOND BLOCK --}}
  <div class="bg-white1">
    <div class="block-portal container">
      <div class="pt-20 pb-10 flex flex-col flex-wrap">

        <div class="w-full lg:w-2/5 py-4">
          <h6 class="text-blue1 tracking-3xwide">PORTAL</h6>
          <h2 class="mb-8 lg:text-xl text-black1">Voor wie</h2>
          <h5 class="mb-8 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
        </div>

        <div class="w-full -mx-6 flex flex-wrap">
          <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
            <div class="portal-image mb-10 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url('@asset("images/img1.png")')"></div>
            <h3 class="text-black1">Adverteerders</h3>
            <h5 class="mb-10 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
            <button class="bg-blue1 text-white">LEES MEER</button>
          </a>

          <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
            <div class="portal-image mb-10 bg-center bg-cover bg-no-repeat border-white1 border-1" style="background-image: url('@asset("images/img1.png")')"></div>
            <h3 class="text-black1">Transporteurs</h3>
            <h5 class="mb-10 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
            <button class="bg-blue1 text-white">LEES MEER</button>
          </a>

          <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
            <div class="portal-image mb-10 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url('@asset("images/img1.png")')"></div>
            <h3 class="text-black1 text-lg leading-tight">Organisaties</h3>
            <h5 class="mb-10 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
            <button class="bg-blue1 text-white">LEES MEER</button>
          </a>
        </div>

      </div>
    </div>
  </div>

{{-- THIRD BLOCK --}}
  <div class="block-news container">
    <div class="py-10 flex flex-wrap">
      <div class="w-full py-8">
        <h2 class="lg:text-xl text-black1">Nieuws</h2>
      </div>

      <div class="w-full -mx-6 flex flex-wrap">
        <a href="" class="w-full px-6 md:w-1/2 xl:w-1/3 inline-block">
          <div class="news-image mb-2 bg-center bg-cover bg-no-repeat border-white1 border-1" style="background-image: url('@asset("images/img.png")')"></div>
          <h6 class="text-grey1 text-right">22-02-2021</h6>
          <h4 class="mt-4 text-black1">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
        </a>

        <a href="" class="w-full mt-10 px-6 md:w-1/2 md:mt-0 xl:w-1/3 inline-block">
          <div class="news-image mb-2 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style=""></div>
          <h6 class="text-grey1 text-right">22-02-2021</h6>
          <h4 class="mt-4 text-black1">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
        </a>

        <div class="w-full mt-10 px-6 xl:w-1/3 xl:mt-0 inline-block">
          <a href="" class="mb-8 flex flex-row items-center">
            <div class="w-2/5">
              <div class="sidenews-image bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
            </div>
            <h5 class="w-3/5 ml-6 mb-0 text-black1">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h5>
          </a>

          <a href="" class="mb-8 flex flex-row items-center">
            <div class="w-2/5">
              <div class="sidenews-image bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
            </div>
            <h5 class="w-3/5 ml-6 mb-0 text-black1">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h5>
          </a>

          <a href="" class="mb-8 flex flex-row items-center">
            <div class="w-2/5">
              <div class="sidenews-image bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
            </div>
            <h5 class="w-3/5 ml-6 mb-0 text-black1">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h5>
          </a>

          <a href="" class="mb-8 flex flex-row items-center">
            <div class="w-full lg:w-2/3 mt-4 flex justify-center lg:justify-end">
              <button class="text-blue1 border-blue1 border">LEES MEER</button>
            </div>
          </a>
        </div>

      </div>
    </div>
  </div>

{{-- TEAM-UP BLOCK --}}
{{-- <div class="block-teamup container">
  <div class="py-20 flex flex-wrap">
    <div class="py-4 w-full lg:w-1/2 xl:w-2/5">
      <h6 class="text-blue1 tracking-3xwide">TEAM UP</h6>
      <h2 class="mb-8 lg:text-xl text-black1">De voordelen van een MovingMessage scherm</h2>
      <h5 class="mb-8 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
    </div>

    <div class="py-20 -mx-10 flex flex-row flex-wrap">
      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
        </div>
        <h3 class="text-black1">Geo-locatie</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
        </div>
        <h3 class="text-black1">e-Paper</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
        </div>
        <h3 class="text-black1">Content</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>

      <div class="mb-10 px-10 w-full md:w-1/2 lg:w-1/3 xl:w-1/4">
        <div class="mb-6 w-1/3">
          <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
        </div>
        <h3 class="text-black1">e-Paper</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
      </div>
    </div>
  </div>
</div> --}}

{{-- ADVERTENTIES --}}
{{-- <div class="block-advertenties container">
  <div class="py-20 flex flex-wrap">
    <div class="my-0 lg:my-20 w-full lg:w-3/5 lg:py-20 lg:pr-10">
        <h6 class="text-blue1 tracking-3xwide">MOGELIJKHEDEN</h6>
        <h2 class="mb-8 lg:text-xl text-black1">Advertenties</h2>
        <h5 class="mb-8 text-grey lg:w-3/5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
        <div class="mb-8 -mx-2 w-1/4 flex flex-row">
          <div class="px-6 py-4 mx-2 rounded-full border-2 border-grey1"><</div>
          <div class="px-6 py-4 mx-2 rounded-full border-2 border-grey1">></div>
        </div>
    </div>

    <div class="my-20 lg:my-0 w-full lg:w-2/5">
      <div class="truck-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/truck.png")')"></div>
    </div>
  </div>
</div> --}}

{{-- SLIDER + TEXT --}}
{{-- <div class="container">
  <div class="py-20 flex flex-row flex-wrap items-center">

    <div class="image-area relative w-full lg:w-1/2 lg:pr-20">
      <div class="image-slide">
        <div class="single-image relative border-black1 border-20 rounded-xl">
          <div class="slide-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/library.png")"></div>
        </div>

        <div class="single-image relative border-black1 border-20 rounded-xl">
          <div class="slide-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/img3.png")"></div>
        </div>

        <div class="single-image relative border-black1 border-20 rounded-xl">
          <div class="slide-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/img4.png")"></div>
        </div>

        <div class="single-image relative border-black1 border-20 rounded-xl">
          <div class="slide-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/img1.png")"></div>
        </div>
      </div>
    </div>

    <div class="w-full lg:w-1/2 lg:pl-20 mt-10 lg:mt-0">
      <h6 class="text-blue1 tracking-2xwide">MOGELIJKHEDEN</h6>
      <h2 class="my-4 lg:text-xl text-black1">Asset & campagne management</h2>
      <h5 class="my-10 w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
    </div>

  </div>
</div> --}}

{{-- STUDIO --}}
{{-- <div class="studio-image py-10 bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/studio.png")')">
  <div class="container">
    <div class="py-40 w-1/2">
      <h6 class="text-white tracking-3xwide">STUDIO</h6>
      <h2 class="mb-8 lg:text-xl text-white">Creative support</h2>
      <h5 class="mb-8 text-white text-opacity-50">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
    </div>
  </div>
</div> --}}

{{-- TEXT + IMAGE --}}
{{-- <div class="bg-white2">
  <div class="container">
    <div class="py-20 -mx-8 flex flex-row flex-wrap items-center">

      <div class="w-full lg:w-1/2 px-8">
        <div class="text-image bg-center bg-cover bg-no-repeat bg-white1 border-white1 border-1"></div>
      </div>

      <div class="w-full lg:w-1/2 mt-10 lg:mt-0 px-8">
        <h6 class="text-blue1 tracking-3xwide">PORTAL</h6>
        <h2 class="mb-8 lg:text-xl text-black1">Toepassingen</h2>
        <h5 class="mb-8 w-4/5 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
      </div>

    </div>
  </div>
</div> --}}

{{-- IMAGE + TEAM-UP --}}
{{-- <div class="container">
  <div class="py-20 flex flex-wrap items-center">

    <div class="lg:pr-20 w-full lg:w-1/2">
      <div class="truck-image bg-center bg-cover bg-no-repeat" style="background-image: url('@asset("images/truck.png")')"></div>
    </div>

    <div class="py-10 lg:pl-20 w-full lg:w-1/2">
      <div class="py-8">
        <h6 class="text-blue1 tracking-3xwide">TEAM UP</h6>
        <h2 class="mb-8 lg:text-xl text-black1">Krachtig platform</h2>
        <h5 class="mb-8 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
      </div>

      <div class="-mx-8 flex flex-row flex-wrap">
        <div class="mb-8 px-8 w-full lg:w-1/2">
          <div class="mb-6 w-1/3">
            <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
          </div>
          <h3 class="text-black1">Laag energieverbruik</h3>
          <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        </div>

        <div class="mb-8 px-8 w-full lg:w-1/2">
          <div class="mb-6 w-1/3">
            <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
          </div>
          <h3 class="text-black1">Niet intrusive</h3>
          <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        </div>

        <div class="mb-8 px-8 w-full lg:w-1/2">
          <div class="mb-6 w-1/3">
            <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
          </div>
          <h3 class="text-black1">Kwalitatieve uitstraling</h3>
          <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        </div>

        <div class="mb-8 px-8 w-full lg:w-1/2">
          <div class="mb-6 w-1/3">
            <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
          </div>
          <h3 class="text-black1">e-Paper</h3>
          <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        </div>
      </div>
    </div>

  </div>
</div> --}}


{{-- TEXT + HOVER BOXES --}}
{{-- <div class="container">
  <div class="py-20 flex flex-wrap">
    <div class="w-full">
      <h6 class="text-blue1 tracking-2xwide">prijzen</h6>
      <h2 class="my-6 lg:text-xl text-black1">Oplossingen voor elke scope</h2>
      <h5 class="w-full lg:w-1/2 text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis. Duis eget nulla imperdiet.</h5>
    </div>

    <div class="w-full py-10 flex flex-row flex-wrap text-center">
      <div class="hoverbox p-20 w-full lg:w-1/3">
        <h3 class="my-6 text-black1">Small</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        <h2 class="w-full lg:text-xl">€ 50,- </h2>
        <h5 class="w-full text-grey">Per maand</h5>
      </div>

      <div class="hoverbox p-20 w-full lg:w-1/3">
        <h3 class="my-6 text-black1">Medium</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        <h2 class="w-full lg:text-xl">€ 75,- </h2>
        <h5 class="w-full text-grey">Per maand</h5>
      </div>

      <div class="hoverbox p-20 w-full lg:w-1/3">
        <h3 class="my-6 text-black1">Large</h3>
        <h5 class="w-full text-grey">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt.</h5>
        <h2 class="w-full lg:text-xl">€ 100,- </h2>
        <h5 class="w-full text-grey">Per maand</h5>
      </div>
    </div>

    <div class="w-full flex flex-row flex-wrap justify-center items-center">
      <div class="w-1/12 mx-4">
        <div class="teamup-image rounded-full bg-grey1 bg-center bg-cover bg-no-repeat border-white1 border-1""></div>
      </div>
      <h3 class="text-black1">Vragen? Neem contact op met Gijs<br><a class="text-blue1">gijs@movingmessage.com</a></h3>
    </div>
  </div>
</div> --}}

{{-- Nieuws --}}
{{-- <div class="container">
  <div class="py-20 flex flex-wrap">
    <div class=" py-10 lg:text-2xl"><h1>Nieuws</h1></div>

    <div class="w-full -mx-6 flex flex-wrap">
      <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url('@asset("images/img.png")')"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full px-6 pb-20 md:w-1/2 lg:w-1/3 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

    </div>
  </div>
</div> --}}

{{-- Nieuws detail --}}
{{-- <div class="container">
  <div class="py-20 flex flex-wrap">
    <a href="" class="flex flex-row">
      <div class="mb-10 lg:mb-0">
        <button class="text-blue1 border-blue1 border">TERUG</button>
      </div>
    </a>

    <div class="lg:w-3/5 px-0 lg:px-20">
      <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1" style="background-image: url('@asset("images/img.png")')"></div>
      <h6 class="mb-6 text-grey1">22-02-2021</h6>
      <h3 class="mb-10 font-normal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit, dolor a luctus tincidunt, diam ex gravida urna, ullamcorper consequat nibh est at felis.</h3>
      <h5 class="w-full text-grey">
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed fringilla luctus lectus eget posuere. Nulla facilisi. Aliquam vestibulum erat sit amet diam pulvinar dapibus. Integer lobortis lobortis libero quis accumsan. Sed pellentesque lacus odio, nec auctor risus placerat in. Sed efficitur scelerisque convallis. Quisque justo sapien, molestie nec dapibus et, ullamcorper nec sem. Etiam eget suscipit augue. Vestibulum et tristique lorem. Aliquam pulvinar est sed risus congue laoreet a sit amet diam. Suspendisse potenti. Nullam pretium tellus libero, et sagittis erat egestas at. Donec sem sapien, ultrices vitae efficitur eu, hendrerit nec sem. Pellentesque fermentum, purus id varius interdum, ipsum justo tempor lorem, sit amet cursus nisl dolor lobortis enim.<br>
      <br>
      Quisque ac leo ut augue convallis gravida vitae vitae magna. Sed posuere egestas pulvinar. Sed tempor enim a ipsum consequat mattis. Nunc interdum tellus vel malesuada pretium. In at elit aliquet, commodo metus in, convallis mauris. Etiam hendrerit feugiat felis sit amet tempor. Duis placerat dolor sagittis mi consectetur bibendum.<br>
      <br>
      Vestibulum pellentesque eros ut elementum convallis. Mauris eget diam et massa scelerisque tempus. Proin ultrices ante at neque volutpat feugiat. Mauris tempor nisi in augue aliquam, consectetur tincidunt lacus tempor. Cras tincidunt leo a diam dapibus rutrum. In faucibus porttitor libero pellentesque tincidunt. Aliquam bibendum condimentum diam, eget lobortis ex. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum in faucibus enim, vel ornare metus.<br>
      <br>
      Nulla odio tellus, elementum sit amet dictum posuere, elementum a arcu. Aenean ac placerat quam. Donec id nulla eget nunc laoreet tristique. Proin rutrum felis eget nisl eleifend convallis. Donec ac tortor ullamcorper, egestas orci id, porttitor dolor. Sed lobortis fermentum sapien, in dictum diam varius eget. Fusce sit amet eros vel est rhoncus vestibulum. Quisque lobortis massa quis volutpat sodales. Cras aliquet ex at massa bibendum bibendum. Proin scelerisque commodo magna, ultricies finibus lectus elementum in. Phasellus lobortis accumsan elementum. Integer at orci non quam faucibus vehicula. Interdum et malesuada fames ac ante ipsum primis in faucibus.<br>
      </h5>
    </div>

    <div class="lg:w-1/5 mt-20 lg:mt-0 ml-0 lg:ml-10 flex flex-col flex-wrap">
      <a href="" class="w-full mb-10 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>

      <a href="" class="w-full mb-10 inline-block">
        <div class="nieuws-image mb-4 bg-center bg-cover bg-no-repeat bg-white2 border-white1 border-1"></div>
        <h6 class="mb-6 text-grey1 text-right">22-02-2021</h6>
        <h4 class="mb-8">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas blandit.</h4>
      </a>
    </div>

  </div>
</div> --}}



  @endwhile
@endsection




