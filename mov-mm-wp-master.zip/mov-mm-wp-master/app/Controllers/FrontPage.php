<?php

namespace App\Controllers;

use Sober\Controller\Controller;

class FrontPage extends Controller
{

}
